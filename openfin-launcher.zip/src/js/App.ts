let _isMenuOpen = false;
_isMenuOpen = (window.innerHeight > 70 ? true : false);

var elem = document.getElementById('exitLink-tearout');

if(elem != null)
{
    elem.addEventListener("click", (e:Event) => exit());
}

function exit(){
    fin.desktop.Application.getCurrent().terminate();
}

var appButton = document.getElementById('launch-app-button');
if(appButton != null)
{
    appButton.addEventListener("click", (e:Event) => toggle());
}

function toggle(){
    expandAppList(_isMenuOpen ? false : true);
    _isMenuOpen = (window.innerHeight > 70 ? true : false);
}

function expandAppList(open: boolean){
    fin.desktop.Window.getCurrent().animate(
        {
            size: {
                width: 408,
                height: open ? 250 : 67,
                duration: 100
            }
        }, { interrupt: false }
    );
}