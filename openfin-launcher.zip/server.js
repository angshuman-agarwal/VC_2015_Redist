const openfinLauncher = require('hadouken-js-adapter');
const path = require("path");
const express = require("express");
const http = require('http');

const configPath = path.resolve("./src/app.json");

const app = express();

app.use(express.static("./dist"));

http.createServer(app).listen(9009, () => {
    console.log("Server created, starting OpenFin...");
    openfinLauncher.launch({ manifestUrl: configPath }).catch(err => console.log(err));
});
